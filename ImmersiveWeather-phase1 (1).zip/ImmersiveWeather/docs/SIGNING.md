# توقيع النسخة النهائية (Release)

## الفرق بين debug وrelease
- **debug**: للتجربة. يوقّعه أندرويد بمفتاح مؤقت، ويتغير مفتاحه بين الأجهزة وأجهزة البناء.
- **release**: للتوزيع. يوقَّع بمفتاح **خاص بك** لا يتغير. إن أضعت هذا المفتاح فلن تستطيع تحديث التطبيق المثبت؛ سيلزم حذفه وتثبيت نسخة جديدة.

## 1) إنشاء المفتاح (مرة واحدة فقط)
تحتاج Java على جهازك. في Terminal (أو PowerShell):

```
keytool -genkeypair -v -keystore release.jks -alias weather -keyalg RSA -keysize 2048 -validity 10000
```
اختر كلمة مرور قوية واحفظها، وأجب عن الأسئلة (يمكن ترك أغلبها فارغًا).

> **احتفظ بنسخة من `release.jks` وكلمة المرور في مكان آمن خارج GitHub (مدير كلمات المرور أو وحدة تخزين خاصة).** لا ترفعه إلى المستودع أبدًا؛ ملف `.gitignore` يمنع ذلك.

## 2) تحويل المفتاح إلى نص
- Linux / macOS: `base64 -w 0 release.jks` (على macOS: `base64 -i release.jks`)
- Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("release.jks"))`

انسخ الناتج الطويل.

## 3) إضافة الأسرار إلى GitHub
في المستودع: **Settings ← Secrets and variables ← Actions ← New repository secret**، وأضف أربعة أسرار بهذه الأسماء بالضبط:

| الاسم | القيمة |
|---|---|
| `KEYSTORE_BASE64` | النص الطويل من الخطوة 2 |
| `KEYSTORE_PASSWORD` | كلمة مرور المفتاح |
| `KEY_ALIAS` | `weather` |
| `KEY_PASSWORD` | كلمة مرور المفتاح (نفسها عادة) |

أسرار GitHub لا تظهر في السجلات ولا يمكن قراءتها بعد حفظها.

## 4) بناء النسخة الموقّعة
**Actions ← Android Build ← Run workflow ← build_type = release ← Run workflow.**
ستجد الملف في Artifacts باسم `ImmersiveWeather-release-apk`.

## 5) التحديثات المستقبلية
استخدم **نفس** المفتاح دائمًا، وارفع `versionCode` في `app/build.gradle.kts` (من 1 إلى 2 ثم 3…). عندها يثبَّت التحديث فوق النسخة القديمة دون فقدان البيانات.
