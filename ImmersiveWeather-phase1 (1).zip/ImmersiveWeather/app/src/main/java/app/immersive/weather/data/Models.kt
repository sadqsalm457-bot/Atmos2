package app.immersive.weather.data

import java.time.LocalDate
import java.time.LocalDateTime

data class Place(
    val name: String,
    val region: String,
    val country: String,
    val lat: Double,
    val lon: Double,
)

data class HourForecast(
    val time: LocalDateTime,
    val tempC: Double,
    val code: Int,
    val precipProb: Int,
    val windKmh: Double,
    val isDay: Boolean,
)

data class DayForecast(
    val date: LocalDate,
    val code: Int,
    val maxC: Double,
    val minC: Double,
    val precipProb: Int,
    val sunrise: LocalDateTime?,
    val sunset: LocalDateTime?,
    val uvMax: Double?,
)

data class Weather(
    val time: LocalDateTime,
    val utcOffsetSec: Int,
    val tempC: Double,
    val feelsC: Double,
    val humidity: Int,
    val pressureHpa: Double,
    val windKmh: Double,
    val windDeg: Int,
    val gustKmh: Double,
    val cloudCover: Int,
    val code: Int,
    val isDay: Boolean,
    val dewC: Double,
    val visibilityM: Double?,
    val precipProb: Int,
    val hourly: List<HourForecast>,
    val daily: List<DayForecast>,
    val fetchedAtMs: Long,
)
