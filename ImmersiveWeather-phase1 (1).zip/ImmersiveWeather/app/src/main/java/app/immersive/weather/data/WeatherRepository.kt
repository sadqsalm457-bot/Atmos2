package app.immersive.weather.data

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale

class WeatherRepository(context: Context) {
    private val prefs = context.getSharedPreferences("weather", Context.MODE_PRIVATE)

    data class Result(val weather: Weather, val offline: Boolean)

    private fun key(p: Place) = "cache_" + String.format(Locale.US, "%.2f_%.2f", p.lat, p.lon)

    /** Tries the network first; falls back to the last cached response when offline. */
    suspend fun load(place: Place): Result = withContext(Dispatchers.IO) {
        val k = key(place)
        try {
            val raw = WeatherApi.fetchRaw(place.lat, place.lon)
            val now = System.currentTimeMillis()
            val weather = WeatherApi.parse(raw, now)
            prefs.edit().putString(k, raw).putLong(k + "_t", now).apply()
            Result(weather, offline = false)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val cached = prefs.getString(k, null) ?: throw e
            Result(WeatherApi.parse(cached, prefs.getLong(k + "_t", 0L)), offline = true)
        }
    }

    fun savePlace(p: Place) {
        val o = JSONObject().put("n", p.name).put("r", p.region).put("c", p.country)
            .put("lat", p.lat).put("lon", p.lon)
        prefs.edit().putString("place", o.toString()).apply()
    }

    fun loadPlace(): Place? {
        val s = prefs.getString("place", null) ?: return null
        return try {
            val o = JSONObject(s)
            Place(o.getString("n"), o.optString("r", ""), o.optString("c", ""), o.getDouble("lat"), o.getDouble("lon"))
        } catch (e: Exception) {
            null
        }
    }
}
