package app.immersive.weather

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import app.immersive.weather.ui.HomeScreen
import app.immersive.weather.ui.WeatherViewModel

class MainActivity : ComponentActivity() {
    private val vm: WeatherViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.any { it }) locate()
            else vm.locationFailed("لم يُمنح إذن الموقع. يمكنك البحث عن مدينة يدويًا.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                // The whole interface is Arabic, so layout is always right-to-left.
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    HomeScreen(vm = vm, onLocate = ::requestLocation)
                }
            }
        }
        if (savedInstanceState == null && vm.state.value.needsPlace) requestLocation()
    }

    private fun requestLocation() {
        val perms = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        val granted = perms.any { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
        if (granted) locate() else permissionLauncher.launch(perms)
    }

    @SuppressLint("MissingPermission")
    private fun locate() {
        val lm = getSystemService(LocationManager::class.java)
        val last = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { p -> runCatching { lm.getLastKnownLocation(p) }.getOrNull() }
            .maxByOrNull { it.time }
        if (last != null && System.currentTimeMillis() - last.time < 6 * 3_600_000L) {
            vm.useLocation(last.latitude, last.longitude)
            return
        }
        val provider = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
            .firstOrNull { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
        if (provider == null) {
            if (last != null) vm.useLocation(last.latitude, last.longitude)
            else vm.locationFailed("خدمة الموقع متوقفة. فعّلها من إعدادات الهاتف أو ابحث عن مدينة.")
            return
        }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                lm.getCurrentLocation(provider, null, ContextCompat.getMainExecutor(this)) { loc ->
                    if (loc != null) vm.useLocation(loc.latitude, loc.longitude)
                    else vm.locationFailed("تعذّر تحديد موقعك. حاول مجددًا أو ابحث عن مدينة.")
                }
            } catch (e: SecurityException) {
                vm.locationFailed("لا يوجد إذن للوصول إلى الموقع.")
            }
        } else {
            vm.locationFailed("تعذّر تحديد موقعك. ابحث عن مدينة يدويًا.")
        }
    }
}
