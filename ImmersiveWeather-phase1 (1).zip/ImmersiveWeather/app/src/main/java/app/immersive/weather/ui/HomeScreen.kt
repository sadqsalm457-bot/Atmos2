package app.immersive.weather.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.immersive.weather.data.DayForecast
import app.immersive.weather.data.HourForecast
import app.immersive.weather.data.Place
import app.immersive.weather.data.Weather
import app.immersive.weather.ui.scene.SceneParams
import app.immersive.weather.ui.scene.SceneType
import app.immersive.weather.ui.scene.WeatherScene
import app.immersive.weather.ui.scene.rainIntensity
import app.immersive.weather.ui.scene.sceneFor
import app.immersive.weather.util.conditionAr
import app.immersive.weather.util.deg
import app.immersive.weather.util.emojiFor
import app.immersive.weather.util.moonPhase
import app.immersive.weather.util.uvLevelAr
import app.immersive.weather.util.windDirAr
import kotlinx.coroutines.delay
import java.time.Duration
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

// Arabic names with Western digits (numeral switching arrives with the settings screen).
private val AR: Locale = Locale.forLanguageTag("ar-u-nu-latn")
private val FMT_HOUR = DateTimeFormatter.ofPattern("h a", AR)
private val FMT_TIME = DateTimeFormatter.ofPattern("h:mm a", AR)
private val FMT_DATE = DateTimeFormatter.ofPattern("EEEE، d MMMM", AR)
private val FMT_DAY = DateTimeFormatter.ofPattern("EEEE", AR)

private fun sceneParamsFor(w: Weather?, h: HourForecast?): SceneParams {
    if (w == null) {
        val day = LocalTime.now().hour in 6..18
        return SceneParams(SceneType.CLEAR, day, 24.0, 10, 0f, 5.0, 270)
    }
    val code = h?.code ?: w.code
    val type = sceneFor(code, w.cloudCover)
    val cover = if (h == null) w.cloudCover else when (type) {
        SceneType.CLEAR -> 5
        SceneType.PARTLY -> 50
        else -> 90
    }
    return SceneParams(
        type = type,
        isDay = h?.isDay ?: w.isDay,
        tempC = h?.tempC ?: w.tempC,
        cloudCover = cover,
        rainIntensity = rainIntensity(code),
        windKmh = h?.windKmh ?: w.windKmh,
        windDeg = w.windDeg,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: WeatherViewModel, onLocate: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()
    var selectedHour by remember { mutableStateOf<Int?>(null) }
    var showSearch by remember { mutableStateOf(false) }
    val w = state.weather
    LaunchedEffect(state.place) { selectedHour = null }

    val hour = selectedHour?.let { w?.hourly?.getOrNull(it) }
    val params = remember(w, hour) { sceneParamsFor(w, hour) }

    WeatherScene(params, scroll = { scrollState.value.toFloat() }, modifier = Modifier.fillMaxSize()) {
        when {
            w != null -> PullToRefreshBox(
                isRefreshing = state.refreshing,
                onRefresh = { vm.refresh() },
                modifier = Modifier.fillMaxSize(),
            ) {
                Dashboard(
                    w = w,
                    place = state.place,
                    offline = state.offline,
                    error = state.error,
                    hour = hour,
                    selectedHour = selectedHour,
                    onSelectHour = { selectedHour = it },
                    onSearch = { showSearch = true },
                    onLocate = onLocate,
                    scrollState = scrollState,
                )
            }
            state.needsPlace -> Welcome(state.error, onLocate = onLocate, onSearch = { showSearch = true })
            state.error != null -> Centered {
                T(state.error ?: "", 16, align = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { vm.refresh() }) { Text("إعادة المحاولة") }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { showSearch = true }) { Text("اختيار مدينة أخرى") }
            }
            else -> Centered {
                CircularProgressIndicator(color = Color.White)
                Spacer(Modifier.height(16.dp))
                T("جارٍ تحميل الطقس…", 16)
            }
        }
    }

    if (showSearch) {
        SearchDialog(
            vm = vm,
            onDismiss = { showSearch = false },
            onPick = { vm.select(it); showSearch = false },
            onLocate = onLocate,
        )
    }
}

// ------------------------------------------------------------------ building blocks

@Composable
private fun T(
    text: String,
    size: Int,
    weight: FontWeight = FontWeight.Normal,
    alpha: Float = 1f,
    modifier: Modifier = Modifier,
    align: TextAlign? = null,
) {
    Text(
        text = text,
        modifier = modifier,
        color = Color.White.copy(alpha = alpha),
        fontSize = size.sp,
        fontWeight = weight,
        textAlign = align,
        style = LocalTextStyle.current.copy(shadow = Shadow(Color(0x55000000), Offset(0f, 2f), 8f)),
    )
}

@Composable
private fun Centered(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        content = content,
    )
}

@Composable
private fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val base = modifier
        .clip(RoundedCornerShape(26.dp))
        .background(Brush.verticalGradient(listOf(Color.White.copy(0.17f), Color.White.copy(0.07f))))
    Column((if (onClick != null) base.clickable(onClick = onClick) else base).padding(16.dp), content = content)
}

@Composable
private fun Welcome(error: String?, onLocate: () -> Unit, onSearch: () -> Unit) {
    Centered {
        T("نافذة الطقس", 34, FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        T(
            "اسمح بالوصول إلى موقعك لعرض الطقس الحقيقي من حولك، أو ابحث عن مدينتك يدويًا.",
            16, alpha = 0.85f, align = TextAlign.Center,
        )
        if (error != null) {
            Spacer(Modifier.height(12.dp))
            T(error, 14, alpha = 0.8f, align = TextAlign.Center)
        }
        Spacer(Modifier.height(24.dp))
        Button(onClick = onLocate) { Text("تحديد موقعي تلقائيًا") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onSearch) { Text("البحث عن مدينة") }
    }
}

// ------------------------------------------------------------------ dashboard

@Composable
private fun Dashboard(
    w: Weather,
    place: Place?,
    offline: Boolean,
    error: String?,
    hour: HourForecast?,
    selectedHour: Int?,
    onSelectHour: (Int?) -> Unit,
    onSearch: () -> Unit,
    onLocate: () -> Unit,
    scrollState: ScrollState,
) {
    val zone = ZoneOffset.ofTotalSeconds(w.utcOffsetSec)
    var nowLocal by remember(w.utcOffsetSec) { mutableStateOf(LocalDateTime.now(zone)) }
    LaunchedEffect(w.utcOffsetSec) {
        while (true) {
            nowLocal = LocalDateTime.now(zone)
            delay(30_000)
        }
    }
    val today = w.daily.firstOrNull()
    val shownTemp = (hour?.tempC ?: w.tempC).roundToInt()
    val shownCode = hour?.code ?: w.code

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .statusBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        // ---- header
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T(place?.name ?: "", 26, FontWeight.SemiBold)
                val sub = listOfNotNull(place?.region, place?.country).filter { it.isNotBlank() }.joinToString("، ")
                if (sub.isNotEmpty()) T(sub, 14, alpha = 0.75f)
                T("${nowLocal.format(FMT_DATE)} • ${nowLocal.format(FMT_TIME)}", 14, alpha = 0.75f)
            }
            IconButton(onClick = onLocate) { Icon(Icons.Default.LocationOn, contentDescription = "موقعي", tint = Color.White) }
            IconButton(onClick = onSearch) { Icon(Icons.Default.Search, contentDescription = "بحث", tint = Color.White) }
        }

        if (offline) {
            val mins = ((System.currentTimeMillis() - w.fetchedAtMs) / 60000).coerceAtLeast(0)
            Spacer(Modifier.height(8.dp))
            T("لا يوجد اتصال — تُعرض آخر بيانات محفوظة (قبل $mins دقيقة).", 13, alpha = 0.85f)
        } else if (error != null) {
            Spacer(Modifier.height(8.dp))
            T(error, 13, alpha = 0.85f)
        }

        // ---- main temperature
        Spacer(Modifier.height(28.dp))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            AnimatedContent(
                targetState = shownTemp,
                transitionSpec = {
                    (slideInVertically(tween(350)) { it / 3 } + fadeIn(tween(350)))
                        .togetherWith(slideOutVertically(tween(350)) { -it / 3 } + fadeOut(tween(250)))
                },
                label = "temp",
            ) { v ->
                T("\u200E$v°", 112, FontWeight.ExtraLight)
            }
            T(conditionAr(shownCode), 26, FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            if (hour == null) {
                T("الإحساس الفعلي ${w.feelsC.deg()}", 16, alpha = 0.85f)
            } else {
                T("توقّع الساعة ${hour.time.format(FMT_HOUR)} — اضغط «الآن» للعودة", 14, alpha = 0.85f)
            }
            if (today != null) {
                T("العظمى ${today.maxC.deg()}   •   الصغرى ${today.minC.deg()}", 16, alpha = 0.85f)
            }
        }

        // ---- hourly
        Spacer(Modifier.height(28.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            T("التوقعات بالساعة", 15, FontWeight.Medium, 0.8f)
            Spacer(Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                items(w.hourly.size) { i ->
                    HourItem(w.hourly[i], isNow = i == 0, selected = (selectedHour ?: 0) == i) {
                        onSelectHour(if (i == 0) null else i)
                    }
                }
            }
        }

        // ---- daily
        Spacer(Modifier.height(16.dp))
        DailyCard(w.daily)

        // ---- details
        Spacer(Modifier.height(16.dp))
        InfoGrid(w, today, nowLocal)

        // ---- data honesty
        Spacer(Modifier.height(20.dp))
        T(
            "مصدر البيانات: Open-Meteo. القياسات والتوقعات حقيقية وتُحدَّث تلقائيًا. أما حركة المطر والغيوم والبرق " +
                "على الشاشة فمحاكاة بصرية مستوحاة من حالة الطقس وليست قياسًا فعليًا.",
            12, alpha = 0.6f, align = TextAlign.Center,
        )
        Spacer(Modifier.navigationBarsPadding().height(24.dp))
    }
}

@Composable
private fun HourItem(h: HourForecast, isNow: Boolean, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) Color.White.copy(alpha = 0.20f) else Color.Transparent
    Column(
        Modifier
            .width(68.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        T(if (isNow) "الآن" else h.time.format(FMT_HOUR), 13, if (isNow) FontWeight.Bold else FontWeight.Normal, 0.9f)
        T(emojiFor(h.code, h.isDay), 22)
        T(h.tempC.deg(), 16, FontWeight.Medium)
        T("💧${h.precipProb}%", 11, alpha = 0.75f)
        T("${h.windKmh.roundToInt()} كم/س", 11, alpha = 0.65f)
    }
}

@Composable
private fun DailyCard(days: List<DayForecast>) {
    if (days.isEmpty()) return
    var expanded by remember { mutableStateOf<Int?>(null) }
    val weekMin = days.minOf { it.minC }
    val weekMax = days.maxOf { it.maxC }
    GlassCard(Modifier.fillMaxWidth()) {
        T("توقعات 7 أيام", 15, FontWeight.Medium, 0.8f)
        days.forEachIndexed { i, d ->
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { expanded = if (expanded == i) null else i }
                    .padding(vertical = 10.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val label = when (i) { 0 -> "اليوم"; 1 -> "غدًا"; else -> d.date.format(FMT_DAY) }
                    T(label, 15, modifier = Modifier.width(72.dp))
                    T(emojiFor(d.code, true), 20, modifier = Modifier.width(30.dp))
                    T(if (d.precipProb >= 20) "${d.precipProb}%" else "", 12, alpha = 0.7f, modifier = Modifier.width(38.dp))
                    T(d.minC.deg(), 15, alpha = 0.75f, modifier = Modifier.width(44.dp), align = TextAlign.Center)
                    RangeBar(d.minC, d.maxC, weekMin, weekMax, Modifier.weight(1f).height(6.dp))
                    T(d.maxC.deg(), 15, FontWeight.Medium, modifier = Modifier.width(44.dp), align = TextAlign.Center)
                }
                AnimatedVisibility(
                    visible = expanded == i,
                    enter = expandVertically(tween(250)) + fadeIn(),
                    exit = shrinkVertically(tween(200)) + fadeOut(),
                ) {
                    Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        T(conditionAr(d.code), 14, FontWeight.Medium)
                        T("احتمال الهطول: ${d.precipProb}%", 13, alpha = 0.8f)
                        d.uvMax?.let { T("الأشعة فوق البنفسجية: ${it.roundToInt()} (${uvLevelAr(it)})", 13, alpha = 0.8f) }
                        if (d.sunrise != null && d.sunset != null) {
                            T("الشروق ${d.sunrise.format(FMT_TIME)}   •   الغروب ${d.sunset.format(FMT_TIME)}", 13, alpha = 0.8f)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RangeBar(min: Double, max: Double, weekMin: Double, weekMax: Double, modifier: Modifier) {
    Canvas(modifier) {
        val span = (weekMax - weekMin).coerceAtLeast(1.0)
        val lo = ((min - weekMin) / span).toFloat()
        val hi = ((max - weekMin) / span).toFloat()
        val h = size.height
        drawRoundRect(Color.White.copy(0.18f), size = size, cornerRadius = CornerRadius(h / 2))
        // RTL layout: the minimum sits on the right side, so the bar is mirrored.
        val x0 = (1f - hi) * size.width
        val x1 = (1f - lo) * size.width
        drawRoundRect(
            Brush.horizontalGradient(listOf(Color(0xFFFFB347), Color(0xFF7FC8FF)), startX = x0, endX = x1),
            topLeft = Offset(x0, 0f),
            size = Size((x1 - x0).coerceAtLeast(h), h),
            cornerRadius = CornerRadius(h / 2),
        )
    }
}

// ------------------------------------------------------------------ detail cards

@Composable
private fun InfoCard(title: String, value: String, sub: String?, modifier: Modifier, extra: @Composable () -> Unit = {}) {
    GlassCard(modifier) {
        T(title, 13, alpha = 0.7f)
        Spacer(Modifier.height(6.dp))
        T(value, 22, FontWeight.Medium)
        if (sub != null) T(sub, 13, alpha = 0.75f)
        extra()
    }
}

@Composable
private fun InfoRow(content: @Composable (Modifier) -> Unit, second: @Composable (Modifier) -> Unit) {
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        content(Modifier.weight(1f).fillMaxHeight())
        second(Modifier.weight(1f).fillMaxHeight())
    }
}

@Composable
private fun InfoGrid(w: Weather, today: DayForecast?, now: LocalDateTime) {
    val moon = remember(now.toLocalDate()) { moonPhase(now.toLocalDate()) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        InfoRow(
            { InfoCard("الرطوبة", "${w.humidity}%", null, it) },
            { InfoCard("نقطة الندى", w.dewC.deg(), null, it) },
        )
        InfoRow(
            {
                InfoCard("الرياح", "${w.windKmh.roundToInt()} كم/س", "رياح ${windDirAr(w.windDeg)}", it) {
                    Spacer(Modifier.height(6.dp))
                    WindCompass(w.windDeg)
                }
            },
            { InfoCard("هبّات الرياح", "${w.gustKmh.roundToInt()} كم/س", null, it) },
        )
        InfoRow(
            { InfoCard("الضغط الجوي", "${w.pressureHpa.roundToInt()}", "هكتوباسكال", it) },
            {
                val vis = w.visibilityM
                InfoCard("مدى الرؤية", if (vis == null) "—" else "${(vis / 1000).roundToInt().coerceAtLeast(0)} كم", null, it)
            },
        )
        InfoRow(
            {
                val uv = today?.uvMax
                InfoCard("الأشعة فوق البنفسجية", if (uv == null) "—" else "${uv.roundToInt()}", uv?.let { u -> uvLevelAr(u) }, it)
            },
            { InfoCard("الغطاء السحابي", "${w.cloudCover}%", null, it) },
        )
        InfoRow(
            {
                InfoCard(
                    "احتمال الهطول", "${w.precipProb}%",
                    if (w.precipProb >= 50) "الهطول متوقع" else "الهطول غير مرجّح", it,
                )
            },
            { InfoCard("القمر", moon.name, "الإضاءة ${moon.illumination}%", it) },
        )
        if (today?.sunrise != null && today.sunset != null) {
            SunCard(today.sunrise, today.sunset, now)
        }
    }
}

@Composable
private fun WindCompass(deg: Int) {
    Canvas(Modifier.size(44.dp)) {
        val c = center
        val r = size.minDimension / 2 - 2.dp.toPx()
        drawCircle(Color.White.copy(0.35f), r, c, style = Stroke(1.5.dp.toPx()))
        // Arrow points to where the wind is blowing (opposite of the "from" direction).
        rotate((deg + 180).toFloat(), pivot = c) {
            val tip = Offset(c.x, c.y - r * 0.75f)
            val tail = Offset(c.x, c.y + r * 0.6f)
            drawLine(Color.White, tail, tip, strokeWidth = 2.5.dp.toPx(), cap = StrokeCap.Round)
            drawLine(Color.White, tip, Offset(c.x - r * 0.28f, c.y - r * 0.4f), strokeWidth = 2.5.dp.toPx(), cap = StrokeCap.Round)
            drawLine(Color.White, tip, Offset(c.x + r * 0.28f, c.y - r * 0.4f), strokeWidth = 2.5.dp.toPx(), cap = StrokeCap.Round)
        }
    }
}

@Composable
private fun SunCard(sunrise: LocalDateTime, sunset: LocalDateTime, now: LocalDateTime) {
    val total = Duration.between(sunrise, sunset).seconds.coerceAtLeast(1)
    val passed = Duration.between(sunrise, now).seconds
    val progress = (passed.toFloat() / total).coerceIn(0f, 1f)
    val up = now.isAfter(sunrise) && now.isBefore(sunset)
    GlassCard(Modifier.fillMaxWidth()) {
        T("الشروق والغروب", 13, alpha = 0.7f)
        Canvas(Modifier.fillMaxWidth().height(80.dp).padding(top = 8.dp)) {
            val stroke = 3.dp.toPx()
            val r = (size.width / 2f - 12.dp.toPx()).coerceAtMost(size.height - 8.dp.toPx())
            val c = Offset(size.width / 2f, size.height - 6.dp.toPx())
            val tl = Offset(c.x - r, c.y - r)
            val sz = Size(r * 2, r * 2)
            drawLine(Color.White.copy(0.25f), Offset(c.x - r, c.y), Offset(c.x + r, c.y), strokeWidth = 1.dp.toPx())
            // Mirrored for RTL: sunrise on the right, sunset on the left.
            drawArc(Color.White.copy(0.25f), 0f, -180f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            if (progress > 0f) {
                drawArc(Color(0xFFFFC857), 0f, -180f * progress, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            }
            if (up) {
                val a = -Math.PI * progress
                val p = Offset(c.x + r * cos(a).toFloat(), c.y + r * sin(a).toFloat())
                drawCircle(Color(0xFFFFC857).copy(0.35f), 12.dp.toPx(), p)
                drawCircle(Color.White, 6.dp.toPx(), p)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            T("الشروق ${sunrise.format(FMT_TIME)}", 14, alpha = 0.9f)
            T("الغروب ${sunset.format(FMT_TIME)}", 14, alpha = 0.9f)
        }
    }
}

// ------------------------------------------------------------------ search

@Composable
private fun SearchDialog(vm: WeatherViewModel, onDismiss: () -> Unit, onPick: (Place) -> Unit, onLocate: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val results by vm.results.collectAsStateWithLifecycle()
    val searching by vm.searching.collectAsStateWithLifecycle()
    LaunchedEffect(q) {
        delay(450)
        vm.search(q)
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color(0xF2141B27),
            modifier = Modifier.fillMaxWidth().padding(16.dp),
        ) {
            Column(Modifier.padding(20.dp)) {
                T("ابحث عن مدينة", 20, FontWeight.SemiBold)
                OutlinedTextField(
                    value = q,
                    onValueChange = { q = it },
                    singleLine = true,
                    placeholder = { Text("مثال: الرياض، القاهرة، دبي") },
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                )
                TextButton(onClick = { onLocate(); onDismiss() }) {
                    Icon(Icons.Default.LocationOn, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("استخدم موقعي الحالي")
                }
                if (searching) LinearProgressIndicator(Modifier.fillMaxWidth())
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(results) { p ->
                        Column(Modifier.fillMaxWidth().clickable { onPick(p) }.padding(vertical = 12.dp)) {
                            T(p.name, 17, FontWeight.Medium)
                            val sub = listOf(p.region, p.country).filter { it.isNotBlank() }.joinToString("، ")
                            if (sub.isNotEmpty()) T(sub, 13, alpha = 0.65f)
                        }
                    }
                }
            }
        }
    }
}
