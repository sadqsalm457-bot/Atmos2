package app.immersive.weather.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

/** Real weather data from Open-Meteo (https://open-meteo.com). No API key required. */
object WeatherApi {

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", "ImmersiveWeather/0.1")
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun fetchRaw(lat: Double, lon: Double): String = httpGet(
        "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation," +
            "weather_code,cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m,dew_point_2m" +
            "&hourly=temperature_2m,weather_code,precipitation_probability,wind_speed_10m,visibility,is_day" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max," +
            "sunrise,sunset,uv_index_max" +
            "&timezone=auto&forecast_days=7&wind_speed_unit=kmh&temperature_unit=celsius"
    )

    private fun JSONArray.dblOrNull(i: Int): Double? = if (isNull(i)) null else optDouble(i)
    private fun JSONArray.timeOrNull(i: Int): LocalDateTime? = if (isNull(i)) null else LocalDateTime.parse(getString(i))

    fun parse(raw: String, fetchedAtMs: Long): Weather {
        val root = JSONObject(raw)
        val cur = root.getJSONObject("current")
        val now = LocalDateTime.parse(cur.getString("time"))

        val h = root.getJSONObject("hourly")
        val ht = h.getJSONArray("time")
        val hTemp = h.getJSONArray("temperature_2m")
        val hCode = h.getJSONArray("weather_code")
        val hProb = h.getJSONArray("precipitation_probability")
        val hWind = h.getJSONArray("wind_speed_10m")
        val hDay = h.getJSONArray("is_day")
        val nowHour = now.truncatedTo(ChronoUnit.HOURS)
        var start = 0
        for (i in 0 until ht.length()) {
            if (!LocalDateTime.parse(ht.getString(i)).isBefore(nowHour)) { start = i; break }
        }
        val end = minOf(start + 24, ht.length())
        val hours = (start until end).map { i ->
            HourForecast(
                time = LocalDateTime.parse(ht.getString(i)),
                tempC = hTemp.optDouble(i, 0.0),
                code = hCode.optInt(i, 0),
                precipProb = hProb.optInt(i, 0),
                windKmh = hWind.optDouble(i, 0.0),
                isDay = hDay.optInt(i, 1) == 1,
            )
        }
        val visibility = h.optJSONArray("visibility")?.dblOrNull(start)

        val d = root.getJSONObject("daily")
        val dt = d.getJSONArray("time")
        val dCode = d.getJSONArray("weather_code")
        val dMax = d.getJSONArray("temperature_2m_max")
        val dMin = d.getJSONArray("temperature_2m_min")
        val dProb = d.getJSONArray("precipitation_probability_max")
        val dRise = d.getJSONArray("sunrise")
        val dSet = d.getJSONArray("sunset")
        val dUv = d.getJSONArray("uv_index_max")
        val days = (0 until dt.length()).map { i ->
            DayForecast(
                date = LocalDate.parse(dt.getString(i)),
                code = dCode.optInt(i, 0),
                maxC = dMax.optDouble(i, 0.0),
                minC = dMin.optDouble(i, 0.0),
                precipProb = dProb.optInt(i, 0),
                sunrise = dRise.timeOrNull(i),
                sunset = dSet.timeOrNull(i),
                uvMax = dUv.dblOrNull(i),
            )
        }

        return Weather(
            time = now,
            utcOffsetSec = root.optInt("utc_offset_seconds", 0),
            tempC = cur.getDouble("temperature_2m"),
            feelsC = cur.optDouble("apparent_temperature", cur.getDouble("temperature_2m")),
            humidity = cur.optInt("relative_humidity_2m", 0),
            pressureHpa = cur.optDouble("pressure_msl", 0.0),
            windKmh = cur.optDouble("wind_speed_10m", 0.0),
            windDeg = cur.optInt("wind_direction_10m", 0),
            gustKmh = cur.optDouble("wind_gusts_10m", 0.0),
            cloudCover = cur.optInt("cloud_cover", 0),
            code = cur.optInt("weather_code", 0),
            isDay = cur.optInt("is_day", 1) == 1,
            dewC = cur.optDouble("dew_point_2m", 0.0),
            visibilityM = visibility,
            precipProb = hours.firstOrNull()?.precipProb ?: 0,
            hourly = hours,
            daily = days,
            fetchedAtMs = fetchedAtMs,
        )
    }

    fun searchCities(query: String): List<Place> {
        val q = URLEncoder.encode(query.trim(), "UTF-8")
        val raw = httpGet("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=8&language=ar&format=json")
        val arr = JSONObject(raw).optJSONArray("results") ?: return emptyList()
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Place(
                name = o.optString("name", ""),
                region = o.optString("admin1", ""),
                country = o.optString("country", ""),
                lat = o.getDouble("latitude"),
                lon = o.getDouble("longitude"),
            )
        }
    }
}
