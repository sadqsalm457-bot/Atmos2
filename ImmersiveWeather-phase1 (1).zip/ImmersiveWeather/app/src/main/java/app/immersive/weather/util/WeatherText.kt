package app.immersive.weather.util

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt

fun conditionAr(code: Int): String = when (code) {
    0 -> "صحو"
    1 -> "صافٍ غالبًا"
    2 -> "غائم جزئيًا"
    3 -> "غائم"
    45 -> "ضباب"
    48 -> "ضباب متجمّد"
    51 -> "رذاذ خفيف"
    53 -> "رذاذ متوسط"
    55 -> "رذاذ كثيف"
    56, 57 -> "رذاذ متجمّد"
    61 -> "مطر خفيف"
    63 -> "مطر متوسط"
    65 -> "مطر غزير"
    66, 67 -> "مطر متجمّد"
    71 -> "ثلوج خفيفة"
    73 -> "ثلوج متوسطة"
    75 -> "ثلوج كثيفة"
    77 -> "حبيبات ثلجية"
    80 -> "زخّات مطر خفيفة"
    81 -> "زخّات مطر"
    82 -> "زخّات مطر غزيرة"
    85 -> "زخّات ثلج خفيفة"
    86 -> "زخّات ثلج كثيفة"
    95 -> "عاصفة رعدية"
    96, 99 -> "عاصفة رعدية مع برَد"
    else -> "غير معروف"
}

/** Temporary emoji icons; custom Canvas icons come in phase 2. */
fun emojiFor(code: Int, isDay: Boolean): String = when (code) {
    0 -> if (isDay) "☀️" else "🌙"
    1, 2 -> if (isDay) "⛅" else "☁️"
    3 -> "☁️"
    45, 48 -> "🌫️"
    in 51..57 -> "🌦️"
    in 61..67, in 80..82 -> "🌧️"
    in 71..77, 85, 86 -> "❄️"
    95, 96, 99 -> "⛈️"
    else -> "☁️"
}

fun windDirAr(deg: Int): String {
    val names = listOf("شمالية", "شمالية شرقية", "شرقية", "جنوبية شرقية", "جنوبية", "جنوبية غربية", "غربية", "شمالية غربية")
    return names[(((deg % 360) + 360) % 360 / 45.0 + 0.5).toInt() % 8]
}

fun uvLevelAr(uv: Double): String = when {
    uv < 3 -> "منخفض"
    uv < 6 -> "معتدل"
    uv < 8 -> "مرتفع"
    uv < 11 -> "مرتفع جدًا"
    else -> "شديد"
}

/** Temperature with a left-to-right mark so the degree sign stays on the correct side in RTL. */
fun Double.deg(): String {
    val r = roundToInt()
    return "\u200E${if (r == 0) 0 else r}°\u200E"
}

data class Moon(val name: String, val illumination: Int)

/** Computed astronomically on the device (not fetched). */
fun moonPhase(date: LocalDate): Moon {
    val syn = 29.530588853
    val days = ChronoUnit.DAYS.between(LocalDate.of(2000, 1, 6), date).toDouble()
    val phase = (((days % syn) + syn) % syn) / syn
    val illum = ((1 - cos(2 * PI * phase)) / 2 * 100).roundToInt()
    val name = when {
        phase < 0.03 || phase >= 0.97 -> "محاق"
        phase < 0.22 -> "هلال متزايد"
        phase < 0.28 -> "تربيع أول"
        phase < 0.47 -> "أحدب متزايد"
        phase < 0.53 -> "بدر"
        phase < 0.72 -> "أحدب متناقص"
        phase < 0.78 -> "تربيع أخير"
        else -> "هلال متناقص"
    }
    return Moon(name, illum)
}
