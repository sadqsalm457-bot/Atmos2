package app.immersive.weather.ui

import android.app.Application
import android.location.Geocoder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.immersive.weather.data.Place
import app.immersive.weather.data.Weather
import app.immersive.weather.data.WeatherApi
import app.immersive.weather.data.WeatherRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

data class UiState(
    val loading: Boolean = true,
    val refreshing: Boolean = false,
    val place: Place? = null,
    val weather: Weather? = null,
    val offline: Boolean = false,
    val error: String? = null,
    val needsPlace: Boolean = false,
)

class WeatherViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = WeatherRepository(app)

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val _results = MutableStateFlow<List<Place>>(emptyList())
    val results: StateFlow<List<Place>> = _results.asStateFlow()

    private val _searching = MutableStateFlow(false)
    val searching: StateFlow<Boolean> = _searching.asStateFlow()

    private var loadJob: Job? = null
    private var searchJob: Job? = null

    init {
        val saved = repo.loadPlace()
        if (saved != null) select(saved) else _state.value = UiState(loading = false, needsPlace = true)
        // Automatic refresh every 10 minutes while the app is open.
        viewModelScope.launch {
            while (true) {
                delay(10 * 60 * 1000L)
                refresh(showIndicator = false)
            }
        }
    }

    fun select(place: Place) {
        repo.savePlace(place)
        _state.update { it.copy(place = place, weather = null, loading = true, needsPlace = false, error = null, offline = false) }
        refresh()
    }

    fun refresh(showIndicator: Boolean = true) {
        val place = _state.value.place ?: return
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _state.update { it.copy(refreshing = showIndicator && it.weather != null, error = null) }
            try {
                val r = repo.load(place)
                _state.update { it.copy(weather = r.weather, offline = r.offline, loading = false, refreshing = false) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        loading = false,
                        refreshing = false,
                        error = "تعذّر تحميل بيانات الطقس. تحقّق من اتصالك بالإنترنت ثم حاول مجددًا.",
                    )
                }
            }
        }
    }

    fun useLocation(lat: Double, lon: Double) {
        viewModelScope.launch {
            _state.update { it.copy(loading = it.weather == null, error = null) }
            val (city, region, country) = reverseGeocode(lat, lon)
            select(Place(city, region, country, lat, lon))
        }
    }

    fun locationFailed(message: String) {
        _state.update {
            if (it.weather == null) it.copy(loading = false, needsPlace = true, error = message)
            else it.copy(error = message)
        }
    }

    fun search(query: String) {
        searchJob?.cancel()
        if (query.trim().length < 2) {
            _results.value = emptyList()
            _searching.value = false
            return
        }
        searchJob = viewModelScope.launch {
            _searching.value = true
            _results.value = try {
                withContext(Dispatchers.IO) { WeatherApi.searchCities(query) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
            _searching.value = false
        }
    }

    @Suppress("DEPRECATION")
    private suspend fun reverseGeocode(lat: Double, lon: Double): Triple<String, String, String> =
        withContext(Dispatchers.IO) {
            val fallback = Triple("موقعي الحالي", "", "")
            try {
                if (!Geocoder.isPresent()) return@withContext fallback
                val a = Geocoder(getApplication(), Locale("ar")).getFromLocation(lat, lon, 1)?.firstOrNull()
                    ?: return@withContext fallback
                val city = a.locality ?: a.subAdminArea ?: a.adminArea ?: "موقعي الحالي"
                Triple(city, a.adminArea ?: "", a.countryName ?: "")
            } catch (e: Exception) {
                fallback
            }
        }
}
