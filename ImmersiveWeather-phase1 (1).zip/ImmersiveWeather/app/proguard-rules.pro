# Default R8 rules are enough for this project (no reflection-based libraries).
