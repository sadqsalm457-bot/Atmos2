package app.immersive.weather.ui.scene

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.Stable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

enum class SceneType { CLEAR, PARTLY, CLOUDY, RAIN, STORM, SNOW, FOG }

data class SceneParams(
    val type: SceneType,
    val isDay: Boolean,
    val tempC: Double,
    val cloudCover: Int,
    val rainIntensity: Float,
    val windKmh: Double,
    val windDeg: Int,
)

fun sceneFor(code: Int, cloud: Int): SceneType = when (code) {
    0, 1 -> if (cloud > 60) SceneType.PARTLY else SceneType.CLEAR
    2 -> SceneType.PARTLY
    3 -> SceneType.CLOUDY
    45, 48 -> SceneType.FOG
    in 51..67, in 80..82 -> SceneType.RAIN
    in 71..77, 85, 86 -> SceneType.SNOW
    95, 96, 99 -> SceneType.STORM
    else -> SceneType.CLOUDY
}

fun rainIntensity(code: Int): Float = when (code) {
    51 -> 0.25f
    53 -> 0.35f
    55 -> 0.5f
    56, 57 -> 0.4f
    61 -> 0.45f
    63 -> 0.7f
    65 -> 1f
    66 -> 0.5f
    67 -> 0.9f
    80 -> 0.5f
    81 -> 0.8f
    82 -> 1f
    95 -> 0.85f
    96, 99 -> 1f
    else -> 0f
}

// ---------------------------------------------------------------- public composable

/**
 * A layered, procedural weather scene. Content is drawn between a back layer (sky, far clouds,
 * rain, bolts) and a front layer (near clouds, near rain/snow, lightning flash), so weather
 * passes both behind and in front of the interface. Neither canvas consumes touches.
 */
@Composable
fun WeatherScene(
    params: SceneParams,
    scroll: () -> Float,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val (topTarget, bottomTarget) = remember(params.type, params.isDay, params.tempC.roundToInt()) { skyColors(params) }
    val top by animateColorAsState(topTarget, tween(2000), label = "skyTop")
    val bottom by animateColorAsState(bottomTarget, tween(2000), label = "skyBottom")
    val seconds = rememberSeconds()
    val lightning = rememberLightning(params.type == SceneType.STORM)
    val assets = remember(params.type, params.cloudCover / 10, (params.rainIntensity * 10).toInt()) {
        buildAssets(params.type, params.cloudCover, params.rainIntensity)
    }

    Box(modifier) {
        Canvas(Modifier.matchParentSize()) {
            val t = seconds.value
            val sc = scroll()
            drawRect(Brush.verticalGradient(listOf(top, bottom)))
            if (params.type == SceneType.CLEAR || params.type == SceneType.PARTLY) {
                if (params.isDay) {
                    drawSun(t, params, sc)
                    if (params.type == SceneType.CLEAR) drawMotes(assets.motes, t)
                } else {
                    drawStars(assets.stars, t, sc, if (params.type == SceneType.CLEAR) 1f else 0.5f)
                    drawMoon(t, sc)
                }
            }
            drawClouds(assets.clouds, t, params, sc, front = false)
            drawFog(assets.fog, t, sc, front = false)
            drawSnow(assets.flakesBack, t, params)
            drawRain(assets.dropsBack, t, params, front = false)
            drawRipples(assets.ripples, t, params)
            if (params.type == SceneType.STORM) drawBolt(lightning)
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0x30000000))))
        }
        content()
        Canvas(Modifier.matchParentSize()) {
            val t = seconds.value
            val sc = scroll()
            drawClouds(assets.clouds, t, params, sc, front = true)
            drawFog(assets.fog, t, sc, front = true)
            drawRain(assets.dropsFront, t, params, front = true)
            drawSnow(assets.flakesFront, t, params)
            val f = lightning.flash.value
            if (f > 0.01f) drawRect(Color(0xFFDDE8FF).copy(alpha = 0.5f * f))
        }
    }
}

// ---------------------------------------------------------------- time & lightning

@Composable
private fun rememberSeconds(): State<Float> {
    val s = remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        var start = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { n ->
                if (start == 0L) start = n
                s.value = (n - start) / 1_000_000_000f
            }
        }
    }
    return s
}

@Stable
private class LightningState {
    val flash = Animatable(0f)
    var seed by mutableIntStateOf(1)
}

@Composable
private fun rememberLightning(active: Boolean): LightningState {
    val st = remember { LightningState() }
    LaunchedEffect(active) {
        if (!active) {
            st.flash.snapTo(0f)
            return@LaunchedEffect
        }
        while (true) {
            delay(Random.nextLong(3500L, 12000L)) // irregular, never a fixed rhythm
            st.seed = Random.nextInt()
            repeat(Random.nextInt(1, 4)) {
                st.flash.snapTo(1f)
                delay(Random.nextLong(40L, 90L))
                st.flash.snapTo(0.25f)
                delay(Random.nextLong(50L, 110L))
            }
            st.flash.snapTo(0.9f)
            st.flash.animateTo(0f, tween(Random.nextInt(250, 600)))
        }
    }
    return st
}

// ---------------------------------------------------------------- assets

private class Puff(val dx: Float, val dy: Float, val r: Float)
private class Cloud(val x: Float, val y: Float, val scale: Float, val speed: Float, val layer: Int, val puffs: List<Puff>)
private class Drop(val x: Float, val y: Float, val depth: Float)
private class Flake(val x: Float, val y: Float, val depth: Float, val phase: Float)
private class Star(val x: Float, val y: Float, val r: Float, val phase: Float, val speed: Float)
private class Mote(val x: Float, val y: Float, val r: Float, val speed: Float, val phase: Float)
private class FogBlob(val x: Float, val y: Float, val size: Float, val speed: Float, val alpha: Float)
private class Ripple(val x: Float, val y: Float, val offset: Float)

private class Assets(
    val clouds: List<Cloud>,
    val dropsBack: List<Drop>,
    val dropsFront: List<Drop>,
    val flakesBack: List<Flake>,
    val flakesFront: List<Flake>,
    val stars: List<Star>,
    val motes: List<Mote>,
    val fog: List<FogBlob>,
    val ripples: List<Ripple>,
)

private fun buildAssets(type: SceneType, cover: Int, rain: Float): Assets {
    val rnd = Random(42)
    val cloudCount = when (type) {
        SceneType.CLEAR -> if (cover > 10) 2 else 1
        SceneType.PARTLY -> 4 + cover / 25
        SceneType.CLOUDY -> 7 + cover / 40
        SceneType.RAIN -> 8
        SceneType.STORM -> 10
        SceneType.SNOW -> 7
        SceneType.FOG -> 3
    }
    val clouds = List(cloudCount) { i ->
        val layer = i % 3
        Cloud(
            x = rnd.nextFloat(),
            y = 0.04f + 0.42f * rnd.nextFloat(),
            scale = (0.8f + 0.7f * rnd.nextFloat()) * (0.8f + 0.35f * layer),
            speed = 5f + layer * 7f + rnd.nextFloat() * 4f,
            layer = layer,
            puffs = List(6) { j ->
                Puff(
                    dx = (j - 2.5f) * 0.55f + (rnd.nextFloat() - 0.5f) * 0.2f,
                    dy = (rnd.nextFloat() - 0.5f) * 0.35f - (if (j in 2..3) 0.25f else 0f),
                    r = 0.55f + rnd.nextFloat() * 0.35f,
                )
            },
        )
    }
    val dropCount = if (rain > 0f) (40 + 260 * rain).toInt() else 0
    val drops = List(dropCount) { Drop(rnd.nextFloat(), rnd.nextFloat(), rnd.nextFloat()) }
    val flakeCount = if (type == SceneType.SNOW) 140 else 0
    val flakes = List(flakeCount) { Flake(rnd.nextFloat(), rnd.nextFloat(), rnd.nextFloat(), rnd.nextFloat() * 6.28f) }
    return Assets(
        clouds = clouds,
        dropsBack = drops.filter { it.depth < 0.82f },
        dropsFront = drops.filter { it.depth >= 0.82f },
        flakesBack = flakes.filter { it.depth < 0.8f },
        flakesFront = flakes.filter { it.depth >= 0.8f },
        stars = List(70) { Star(rnd.nextFloat(), rnd.nextFloat(), 0.6f + rnd.nextFloat() * 1.4f, rnd.nextFloat() * 6.28f, 0.4f + rnd.nextFloat()) },
        motes = List(26) { Mote(rnd.nextFloat(), rnd.nextFloat(), 1.2f + rnd.nextFloat() * 2f, 0.2f + rnd.nextFloat() * 0.5f, rnd.nextFloat() * 6.28f) },
        fog = if (type == SceneType.FOG) List(8) { FogBlob(rnd.nextFloat(), 0.15f + 0.75f * rnd.nextFloat(), 0.7f + rnd.nextFloat() * 0.6f, 4f + rnd.nextFloat() * 8f, 0.16f + rnd.nextFloat() * 0.14f) } else emptyList(),
        ripples = if (rain > 0.3f) List(14) { Ripple(rnd.nextFloat(), rnd.nextFloat(), rnd.nextFloat()) } else emptyList(),
    )
}

// ---------------------------------------------------------------- sky palette

private fun skyColors(p: SceneParams): Pair<Color, Color> {
    val (t0, b0) = if (p.isDay) when (p.type) {
        SceneType.CLEAR -> 0xFF1976D2 to 0xFF7CC4F5
        SceneType.PARTLY -> 0xFF3B82C4 to 0xFF9CC8E8
        SceneType.CLOUDY -> 0xFF6B7F96 to 0xFFA9B7C6
        SceneType.RAIN -> 0xFF3D4B5E to 0xFF6E7F92
        SceneType.STORM -> 0xFF1F2733 to 0xFF45505F
        SceneType.SNOW -> 0xFF6E86A0 to 0xFFB5C6D8
        SceneType.FOG -> 0xFF7E8C99 to 0xFFAEB8C2
    } else when (p.type) {
        SceneType.CLEAR -> 0xFF050B1F to 0xFF16305F
        SceneType.PARTLY -> 0xFF0B1730 to 0xFF2A3F63
        SceneType.CLOUDY -> 0xFF161E2C to 0xFF34415A
        SceneType.RAIN -> 0xFF0E141E to 0xFF2A3442
        SceneType.STORM -> 0xFF07090E to 0xFF1D232D
        SceneType.SNOW -> 0xFF2A3548 to 0xFF55657D
        SceneType.FOG -> 0xFF2A323C to 0xFF525C68
    }
    var top = Color(t0)
    var bottom = Color(b0)
    // Temperature changes the mood: hot = golden light, cold = icy tint.
    if (p.isDay) {
        val warm = ((p.tempC - 26.0) / 14.0).coerceIn(0.0, 0.35).toFloat()
        if (warm > 0f) {
            top = lerp(top, Color(0xFFFFA24D), warm * 0.5f)
            bottom = lerp(bottom, Color(0xFFFFB46B), warm)
        }
    }
    val cold = ((8.0 - p.tempC) / 20.0).coerceIn(0.0, 0.3).toFloat() * (if (p.isDay) 1f else 0.6f)
    if (cold > 0f) {
        top = lerp(top, Color(0xFF9CCBF2), cold * 0.6f)
        bottom = lerp(bottom, Color(0xFFD7EEFF), cold)
    }
    return top to bottom
}

private fun Float.wrap(m: Float): Float = ((this % m) + m) % m

// ---------------------------------------------------------------- drawing

private fun DrawScope.drawSun(t: Float, p: SceneParams, scroll: Float) {
    val w = size.width
    val h = size.height
    val cx = w * 0.76f + sin(t * 0.07f) * 6.dp.toPx()
    val cy = h * 0.15f + cos(t * 0.05f) * 4.dp.toPx() - scroll * 0.15f
    val c = Offset(cx, cy)
    val hot = ((p.tempC - 30.0) / 10.0).coerceIn(0.0, 1.0).toFloat()
    val a = if (p.type == SceneType.CLEAR) 1f else 0.7f
    val glowR = w * (0.55f + 0.25f * hot)
    drawCircle(
        Brush.radialGradient(
            listOf(Color(0xFFFFF1B8).copy(alpha = 0.85f * a), Color(0xFFFFC46B).copy(alpha = 0.25f * a), Color.Transparent),
            center = c, radius = glowR,
        ),
        radius = glowR, center = c,
    )
    rotate(t * 3f, pivot = c) {
        for (i in 0 until 12) {
            val rad = Math.toRadians(i * 30.0)
            val dx = cos(rad).toFloat()
            val dy = sin(rad).toFloat()
            val pulse = 0.6f + 0.4f * sin(t * 0.6f + i)
            drawLine(
                Color.White.copy(alpha = 0.10f * a * pulse),
                start = Offset(cx + dx * 40.dp.toPx(), cy + dy * 40.dp.toPx()),
                end = Offset(cx + dx * glowR * 0.9f, cy + dy * glowR * 0.9f),
                strokeWidth = (10 + (i % 3) * 6).dp.toPx(),
                cap = StrokeCap.Round,
            )
        }
    }
    val r = 30.dp.toPx()
    drawCircle(Brush.radialGradient(listOf(Color.White, Color(0xFFFFE9A6)), center = c, radius = r), radius = r, center = c)
}

private fun DrawScope.drawMoon(t: Float, scroll: Float) {
    val c = Offset(size.width * 0.76f, size.height * 0.15f - scroll * 0.15f + sin(t * 0.05f) * 3.dp.toPx())
    val gr = 90.dp.toPx()
    drawCircle(
        Brush.radialGradient(listOf(Color(0x55BFD0FF), Color.Transparent), center = c, radius = gr),
        radius = gr, center = c,
    )
    drawCircle(Color(0xFFF4F1E6), radius = 20.dp.toPx(), center = c)
    drawCircle(Color(0x1A000000), radius = 4.dp.toPx(), center = c + Offset(-6.dp.toPx(), -4.dp.toPx()))
    drawCircle(Color(0x14000000), radius = 3.dp.toPx(), center = c + Offset(5.dp.toPx(), 6.dp.toPx()))
}

private fun DrawScope.drawStars(stars: List<Star>, t: Float, scroll: Float, k: Float) {
    for (s in stars) {
        val a = (0.25f + 0.6f * abs(sin(t * s.speed + s.phase))) * k
        drawCircle(Color.White.copy(alpha = a), s.r.dp.toPx(), Offset(s.x * size.width, s.y * size.height * 0.6f - scroll * 0.05f))
    }
}

private fun DrawScope.drawMotes(motes: List<Mote>, t: Float) {
    val w = size.width
    val h = size.height
    for (m in motes) {
        val x = m.x * w + sin(t * m.speed + m.phase) * 20.dp.toPx()
        val y = (m.y - t * 0.01f * m.speed * 3f).wrap(1f) * h
        drawCircle(Color.White.copy(alpha = 0.25f * (0.5f + 0.5f * sin(t * 0.5f + m.phase))), m.r.dp.toPx(), Offset(x, y))
    }
}

private fun cloudColor(p: SceneParams): Color = when (p.type) {
    SceneType.STORM -> if (p.isDay) Color(0xFF4A5260) else Color(0xFF232933)
    SceneType.RAIN -> if (p.isDay) Color(0xFF7C8796) else Color(0xFF3A4350)
    SceneType.SNOW -> if (p.isDay) Color(0xFFE6EDF5) else Color(0xFF8795AA)
    SceneType.FOG -> if (p.isDay) Color(0xFFDCE2E8) else Color(0xFF6C7886)
    else -> if (p.isDay) Color.White else Color(0xFF9FB0CC)
}

private fun DrawScope.drawClouds(clouds: List<Cloud>, t: Float, p: SceneParams, scroll: Float, front: Boolean) {
    val w = size.width
    val h = size.height
    val col = cloudColor(p)
    val east = -sin(Math.toRadians(p.windDeg.toDouble())).toFloat()
    val dir = if (east >= 0f) 1f else -1f
    val windBoost = 1f + (p.windKmh / 40.0).toFloat().coerceAtMost(2.5f)
    val density = when (p.type) {
        SceneType.CLEAR -> 0.5f
        SceneType.PARTLY -> 0.8f
        else -> 1f
    }
    for (c in clouds) {
        if ((c.layer == 2) != front) continue // near layer is drawn over the UI
        val unit = 60.dp.toPx() * c.scale
        val cw = unit * 3.2f
        val span = w + 2 * cw
        val x = (c.x * span + dir * c.speed.dp.toPx() * windBoost * t).wrap(span) - cw
        val y = c.y * h - scroll * (0.05f + 0.08f * c.layer)
        val layerAlpha = when (c.layer) { 0 -> 0.35f; 1 -> 0.5f; else -> 0.65f * 0.45f }
        val a = layerAlpha * density
        for (pf in c.puffs) {
            val center = Offset(x + pf.dx * unit, y + pf.dy * unit)
            val r = pf.r * unit
            drawCircle(
                Brush.radialGradient(listOf(col.copy(alpha = a), col.copy(alpha = a * 0.6f), Color.Transparent), center = center, radius = r),
                radius = r, center = center,
            )
        }
    }
}

private fun DrawScope.drawRain(drops: List<Drop>, t: Float, p: SceneParams, front: Boolean) {
    if (drops.isEmpty()) return
    val w = size.width
    val h = size.height
    val k = (p.windKmh / 50.0).coerceIn(0.05, 1.0).toFloat() * 0.35f
    val slant = -sin(Math.toRadians(p.windDeg.toDouble())).toFloat() * k
    val col = Color(0xFFD6E8FF)
    val intensity = 0.6f + 0.4f * p.rainIntensity
    for (d in drops) {
        val speed = 0.9f + 1.3f * d.depth
        val len = (10f + 36f * d.depth).dp.toPx()
        val y = ((d.y + speed * t) % 1f) * (h + len) - len
        val x = (d.x * w + slant * y).wrap(w)
        drawLine(
            col.copy(alpha = (0.16f + 0.4f * d.depth) * intensity * (if (front) 0.8f else 1f)),
            start = Offset(x, y),
            end = Offset(x - slant * len, y - len),
            strokeWidth = (0.7f + 1.6f * d.depth).dp.toPx(),
            cap = StrokeCap.Round,
        )
    }
}

private fun DrawScope.drawRipples(ripples: List<Ripple>, t: Float, p: SceneParams) {
    for (r in ripples) {
        val ph = (t * 0.8f + r.offset) % 1f
        val rad = (3f + 20f * ph).dp.toPx()
        val cx = r.x * size.width
        val cy = size.height * (0.9f + 0.08f * r.y)
        drawOval(
            Color.White.copy(alpha = (1f - ph) * 0.35f * p.rainIntensity),
            topLeft = Offset(cx - rad, cy - rad * 0.3f),
            size = Size(rad * 2, rad * 0.6f),
            style = Stroke(1.2.dp.toPx()),
        )
    }
}

private fun DrawScope.drawSnow(flakes: List<Flake>, t: Float, p: SceneParams) {
    if (flakes.isEmpty()) return
    val w = size.width
    val h = size.height
    val windX = -sin(Math.toRadians(p.windDeg.toDouble())).toFloat() * (p.windKmh / 30.0).coerceIn(0.2, 2.0).toFloat()
    for (f in flakes) {
        val speed = 0.05f + 0.10f * f.depth
        val y = ((f.y + speed * t) % 1f) * (h + 20f) - 10f
        val sway = sin(t * (0.6f + f.depth * 0.5f) + f.phase) * (14f * f.depth).dp.toPx()
        val x = (f.x * w + sway + windX * t * 25.dp.toPx() * f.depth).wrap(w)
        drawCircle(Color.White.copy(alpha = 0.45f + 0.4f * f.depth), (1.1f + 3.2f * f.depth).dp.toPx(), Offset(x, y))
    }
}

private fun DrawScope.drawFog(blobs: List<FogBlob>, t: Float, scroll: Float, front: Boolean) {
    if (blobs.isEmpty()) return
    val w = size.width
    val h = size.height
    blobs.forEachIndexed { i, b ->
        if ((i % 2 == 1) != front) return@forEachIndexed
        val bw = b.size * w
        val span = w + bw
        val x = (b.x * span + b.speed.dp.toPx() * t).wrap(span) - bw / 2
        val y = b.y * h - scroll * 0.04f
        val c = Offset(x, y)
        val a = b.alpha * (if (front) 0.6f else 1f)
        scale(1f, 0.38f, pivot = c) {
            drawCircle(
                Brush.radialGradient(listOf(Color.White.copy(alpha = a), Color.Transparent), center = c, radius = bw * 0.6f),
                radius = bw * 0.6f, center = c,
            )
        }
    }
    if (!front) drawRect(Color.White.copy(alpha = 0.08f))
}

private fun boltPath(seed: Int, w: Float, h: Float): Path {
    val r = Random(seed)
    var x = w * (0.2f + 0.6f * r.nextFloat())
    var y = 0f
    val endY = h * (0.45f + 0.2f * r.nextFloat())
    val p = Path()
    p.moveTo(x, y)
    while (y < endY) {
        y += h * (0.03f + 0.04f * r.nextFloat())
        x += (r.nextFloat() - 0.5f) * w * 0.12f
        p.lineTo(x, y)
    }
    return p
}

private fun DrawScope.drawBolt(l: LightningState) {
    val f = l.flash.value
    if (f <= 0.02f) return
    val path = boltPath(l.seed, size.width, size.height)
    drawPath(path, Color(0xFFBFD6FF).copy(alpha = 0.35f * f), style = Stroke(10.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    drawPath(path, Color.White.copy(alpha = f), style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
}
